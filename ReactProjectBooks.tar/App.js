import {Component} from 'react'
import {Route, Switch, Redirect} from 'react-router-dom'
import LoginForm from './components/LoginForm'
import Home from './components/Home'
import BookShelvesComponent from './components/BookShelvesComponent'
import ProtectedRoute from './components/ProtectedRoute'
import BookDetailsComponent from './components/BookDetailsComponent'
import NotFound from './components/NotFound'
import ContextComponent from './ContextComponent/Context'
import CartCompo from './components/CartCompo'
import './App.css'

// use the below bookshelvesList for rendering read status of book items in Bookshelves Route

const upperTabList = [
  {
    id: 1,
    title: 'Home',
    path: '/',
  },
  {
    id: 2,
    title: 'Bookshelves',
    path: '/shelf',
  },
  {
    id: 3,
    title: 'Cart',
    path: '/cart',
  },
]

const bookshelvesList = [
  {
    id: '22526c8e-680e-4419-a041-b05cc239ece4',
    value: 'ALL',
    label: 'All',
  },
  {
    id: '37e09397-fab2-46f4-9b9a-66b2324b2e22',
    value: 'READ',
    label: 'Read',
  },
  {
    id: '2ab42512-3d05-4fba-8191-5122175b154e',
    value: 'CURRENTLY_READING',
    label: 'Currently Reading',
  },
  {
    id: '361d5fd4-9ea1-4e0c-bd47-da2682a5b7c8',
    value: 'WANT_TO_READ',
    label: 'Want to Read',
  },
]

class App extends Component {
  state = {
    button: JSON.parse(localStorage.getItem('buttonTab')),
    themeStatus: JSON.parse(localStorage.getItem('bgTheme')),
    cartList: [],
  }

  themeChangeFunction = () => {
    const present = JSON.parse(localStorage.getItem('bgTheme'))
    const sub = !present
    localStorage.setItem('bgTheme', JSON.stringify(sub))
    this.setState({themeStatus: sub})
  }

  varunFunction = () => {
    const {themeStatus} = this.state
    console.log(themeStatus)
    localStorage.setItem('bgTheme', JSON.stringify(themeStatus))
  }

  presentChange = padma => {
    const updated = upperTabList.filter(eachitem => eachitem.title === padma)
    console.log(updated[0].id)
    const final = JSON.stringify(updated[0].id)
    localStorage.setItem('id', final)
  }

  activeTabChange = meter => {
    const updatedList = bookshelvesList.filter(
      eachitem => eachitem.id === meter,
    )
    const final = JSON.stringify(updatedList[0].id)
    localStorage.setItem('state', final)
  }

  buttonstatusChange = () => {
    const buttonStatus = localStorage.getItem('buttonTab')
    const para = JSON.parse(buttonStatus)
    console.log('varun')
    const tiru = !para
    const varun = JSON.stringify(tiru)
    localStorage.setItem('buttonTab', varun)
    this.setState({button: tiru})
  }

  cartListChange = para => {
    const {id, authorName, coverPic, title} = para
    const {cartList} = this.state
    const details = {
      id,
      authorName,
      coverPic,
      title,
    }
    const updatedCart = cartList.filter(eachItem => eachItem.id !== id)
    const resultantList = [...updatedCart, details]
    this.setState({cartList: resultantList})
  }

  removingCartItem = id => {
    const {cartList} = this.state
    const updatedList = cartList.filter(eachItem => eachItem.id !== id)
    this.setState({cartList: updatedList})
  }

  render() {
    const {button, cartList} = this.state
    console.log(cartList)
    return (
      <>
        <ContextComponent.Provider
          value={{
            present: localStorage.getItem('id'),
            presentChange: this.presentChange,
            activeTab: localStorage.getItem('state'),
            activeTabChange: this.activeTabChange,
            buttonstatusChange: this.buttonstatusChange,
            buttonStatus: button,
            themeChangeFunction: this.themeChangeFunction,
            cartList,
            cartListChange: this.cartListChange,
            removingCartItem: this.removingCartItem,
          }}
        >
          <Switch>
            <Route exact path="/login" component={LoginForm} />
            <ProtectedRoute
              exact
              path="/"
              component={Home}
              functionName={this.buttonstatusChange}
              buttonStatus={button}
            />
            <ProtectedRoute
              exact
              path="/shelf"
              component={BookShelvesComponent}
              functionName={this.buttonstatusChange}
              buttonStatus={button}
            />
            <ProtectedRoute
              exact
              path="/books/:id"
              component={BookDetailsComponent}
              functionName={this.buttonstatusChange}
              buttonStatus={button}
            />
            <ProtectedRoute exact path="/cart" component={CartCompo} />
            <Route exact path="/not-found" component={NotFound} />
            <Redirect to="/not-found" />
          </Switch>
        </ContextComponent.Provider>
      </>
    )
  }
}

export default App
