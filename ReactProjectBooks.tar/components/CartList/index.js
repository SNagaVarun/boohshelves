import ContextComponent from '../../ContextComponent/Context'
import './index.css'

const CartList = props => {
  const {key, sub} = props
  return (
    <ContextComponent.Consumer>
      {value => {
        const {removingCartItem} = value
        const removingFunction = () => {
          removingCartItem(sub.id)
        }
        return (
          <li key={key} className="cart-sub-main-cont">
            <div className="sub-cart-cont">
              <img src={sub.coverPic} alt="Items" className="sub-logo-image" />
              <div>
                <h1 className="sub-cart-heading">{sub.title}</h1>
                <p className="sub-para-cart">{sub.authorName}</p>
              </div>
              <button
                type="button"
                className="delete-class"
                onClick={removingFunction}
              >
                Delete
              </button>
            </div>
          </li>
        )
      }}
    </ContextComponent.Consumer>
  )
}
export default CartList
