import {Component} from 'react'
import Cookies from 'js-cookie'
import Loader from 'react-loader-spinner'
import {BsSearch} from 'react-icons/bs'
import TabsForSmall from '../TabsForSmall'
import Header from '../Header'
import Footer from '../Footer'
import SideBarComponent from '../SideBarComponent'
import BooksList from '../BooksList'
import './index.css'

const apiStatus = {
  initial: 'INITIAL',
  success: 'SUCCESS',
  failure: 'FAILURE',
  inProgress: 'LOADER',
  noJobs: 'NOJOBS',
}

const bookshelvesList = [
  {
    id: '22526c8e-680e-4419-a041-b05cc239ece4',
    value: 'ALL',
    label: 'All',
  },
  {
    id: '37e09397-fab2-46f4-9b9a-66b2324b2e22',
    value: 'READ',
    label: 'Read',
  },
  {
    id: '2ab42512-3d05-4fba-8191-5122175b154e',
    value: 'CURRENTLY_READING',
    label: 'Currently Reading',
  },
  {
    id: '361d5fd4-9ea1-4e0c-bd47-da2682a5b7c8',
    value: 'WANT_TO_READ',
    label: 'Want to Read',
  },
]

class BookShelvesComponent extends Component {
  state = {
    itemsList: [],
    searchValue: '',
    selectedTab: JSON.parse(localStorage.getItem('state')),
    status: apiStatus.initial,
    active: true,
  }

  componentDidMount() {
    this.setState({status: apiStatus.inProgress})
    localStorage.setItem('id', JSON.stringify(2))
    this.getDetails()
  }

  getDetails = async () => {
    const {selectedTab, searchValue} = this.state
    const url = `https://apis.ccbp.in/book-hub/books?shelf=${selectedTab}&search=${searchValue}`
    const token = Cookies.get('jwt_token')
    const option = {
      method: 'GET',
      headers: {
        Authorization: `Bearer ${token}`,
      },
    }
    const response = await fetch(url, option)
    if (response.ok === true) {
      const data = await response.json()
      console.log(url)
      console.log(data)
      const {books} = data
      const updatedData = books.map(eachitem => {
        const sub = {
          id: eachitem.id,
          authorName: eachitem.author_name,
          coverPic: eachitem.cover_pic,
          rating: eachitem.rating,
          readStatus: eachitem.read_status,
          title: eachitem.title,
        }
        return sub
      })
      this.setState({
        itemsList: updatedData,
        status: apiStatus.success,
        active: true,
      })
    } else {
      this.setState({status: apiStatus.failure, active: false})
    }
  }

  searchValueChangeFunction = event => {
    this.setState({searchValue: event.target.value})
  }

  onclickfunctioninput = () => {
    const {searchValue} = this.state
    this.setState({searchValue}, this.getDetails)
  }

  tabChangeFunction = para => {
    const update = bookshelvesList.filter(eachitem => eachitem.id === para)
    const list = update[0].value
    localStorage.setItem('state', JSON.stringify(update[0].value))
    const vaty = JSON.parse(localStorage.getItem('state'))
    this.setState({selectedTab: vaty}, this.getDetails)
  }

  retryFunction = () => {
    this.setState({status: apiStatus.inProgress}, this.getDetails)
  }

  switchingFunction = () => {
    const {status, itemsList} = this.state
    switch (true) {
      case status === apiStatus.inProgress:
        return this.loadingFunction()
      case status === apiStatus.success:
        if (itemsList.length > 0) {
          return this.successFunction()
        }
        return this.noJobsFunction()
      case status === apiStatus.failure:
        return this.failureFunction()
      case status === apiStatus.noJobs:
        return this.noJobsFunction()
      default:
        return null
    }
  }

  loadingFunction = () => {
    const bgCover = JSON.parse(localStorage.getItem('bgTheme'))
    const bgResult = bgCover ? 'dark-details-theme' : 'light-details-theme'
    return (
      <div className={`loading-container ${bgResult}`}>
        <div className="loader-container" testid="loader">
          <Loader type="TailSpin" color="#0284C7" height={50} width={50} />
        </div>
      </div>
    )
  }

  failureFunction = () => {
    const {selectedTab, searchValue, active} = this.state
    const varun = bookshelvesList.filter(
      eachitem => eachitem.value === selectedTab,
    )
    const final = varun[0].label
    const head = active ? 'Bookshelves' : 'Book Shelves'
    const result = JSON.parse(localStorage.getItem('buttonTab'))
    const bgColorBottom = JSON.parse(localStorage.getItem('bgTheme'))
    const bottomColor = bgColorBottom
      ? 'dark-theme-book-shelves'
      : 'light-theme-book-shelves'
    const sideBarBg = bgColorBottom ? 'dark-side-theme' : 'light-side-theme'
    const sideMainHeading = bgColorBottom
      ? 'side-dark-color'
      : 'side-light-color'
    const errorPars = bgColorBottom
      ? 'content-top-dark-para'
      : 'content-top-light-para'
    const inputBg = bgColorBottom ? 'dark-input-theme' : 'light-input-theme'
    const searchIcon = bgColorBottom
      ? 'dark-search-button'
      : 'light-search-button'
    return (
      <div className={`book-shelves-container ${bottomColor}`}>
        <div className="tabs-for-small-cont">
          <>{result ? <TabsForSmall /> : null}</>
        </div>
        <div className="search-small-container">
          <div className="input-search-cont">
            <input
              type="search"
              placeholder="Search"
              className={`input-ele ${inputBg}`}
              value={searchValue}
              onChange={this.searchValueChangeFunction}
            />
            <button
              type="button"
              onClick={this.onclickfunctioninput}
              testid="searchButton"
              className={`search-icon ${searchIcon}`}
            >
              <BsSearch />
            </button>
          </div>
        </div>
        <div className="item-bottom-container">
          <div className={`side-bar-container ${sideBarBg}`}>
            <h1 className={`books-heading ${sideMainHeading}`}>{head}</h1>
            <nav>
              <ul className="list-side-bar-container">
                {bookshelvesList.map(eachitem => (
                  <SideBarComponent
                    key={eachitem.id}
                    sub={eachitem}
                    tabChangeFunction={this.tabChangeFunction}
                    tiru={eachitem.value === selectedTab}
                  />
                ))}
              </ul>
            </nav>
          </div>

          <div className="first-container-item">
            <div className="search-book-cont">
              <div className="books-search-container">
                <h1 className={`type-of-books ${sideMainHeading}`}>
                  {final} Books
                </h1>

                <div className="input-search-cont">
                  <input
                    type="search"
                    placeholder="Search"
                    className={`input-ele ${inputBg}`}
                    value={searchValue}
                    onChange={this.searchValueChangeFunction}
                  />
                  <button
                    type="button"
                    onClick={this.onclickfunctioninput}
                    testid="searchButton"
                    className={`search-icon ${searchIcon}`}
                  >
                    <BsSearch />
                  </button>
                </div>
              </div>
            </div>
            <>
              <div className="failure-container">
                <div className="middle-fail-container">
                  <img
                    src="https://res.cloudinary.com/dh5so11jh/image/upload/v1677258750/Group_7522details-wrong_t7zbet.png"
                    alt="failure view"
                    className="failure-img"
                  />
                  <p className={`error-para ${errorPars}`}>
                    Something went wrong, Please try again.
                  </p>
                  <button
                    type="button"
                    className="tryAgain-button"
                    onClick={this.retryFunction}
                  >
                    Try Again
                  </button>
                </div>
              </div>
            </>
          </div>
        </div>
      </div>
    )
  }

  noJobsFunction = () => {
    const {selectedTab, searchValue, active} = this.state
    const varun = bookshelvesList.filter(
      eachitem => eachitem.value === selectedTab,
    )
    const final = varun[0].label
    const head = active ? 'Bookshelves' : 'Book Shelves'
    const result = JSON.parse(localStorage.getItem('buttonTab'))
    const bgColorBottom = JSON.parse(localStorage.getItem('bgTheme'))
    const bottomColor = bgColorBottom
      ? 'dark-theme-book-shelves'
      : 'light-theme-book-shelves'
    const sideBarBg = bgColorBottom ? 'dark-side-theme' : 'light-side-theme'
    const sideMainHeading = bgColorBottom
      ? 'side-dark-color'
      : 'side-light-color'
    const inputBg = bgColorBottom ? 'dark-input-theme' : 'light-input-theme'
    const searchIcon = bgColorBottom
      ? 'dark-search-button'
      : 'light-search-button'
    const errorPars = bgColorBottom
      ? 'content-top-dark-para'
      : 'content-top-light-para'
    return (
      <div className={`book-shelves-container ${bottomColor}`}>
        <div className="tabs-for-small-cont">
          <>{result ? <TabsForSmall /> : null}</>
        </div>
        <div className="search-small-container">
          <div className="input-search-cont">
            <input
              type="search"
              placeholder="Search"
              className={`input-ele ${inputBg}`}
              value={searchValue}
              onChange={this.searchValueChangeFunction}
            />
            <button
              type="button"
              onClick={this.onclickfunctioninput}
              testid="searchButton"
              className={`search-icon ${searchIcon}`}
            >
              <BsSearch />
            </button>
          </div>
        </div>
        <div className="item-bottom-container">
          <div className={`side-bar-container ${sideBarBg}`}>
            <h1 className={`books-heading ${sideMainHeading}`}>{head}</h1>
            <nav>
              <ul className="list-side-bar-container">
                {bookshelvesList.map(eachitem => (
                  <SideBarComponent
                    key={eachitem.id}
                    sub={eachitem}
                    tabChangeFunction={this.tabChangeFunction}
                    tiru={eachitem.value === selectedTab}
                  />
                ))}
              </ul>
            </nav>
          </div>

          <div className="first-container-item">
            <div className="search-book-cont">
              <div className="books-search-container">
                <h1 className={`type-of-books ${sideMainHeading}`}>
                  {final} Books
                </h1>

                <div className="input-search-cont">
                  <input
                    type="search"
                    placeholder="Search"
                    className={`input-ele ${inputBg}`}
                    value={searchValue}
                    onChange={this.searchValueChangeFunction}
                  />
                  <button
                    type="button"
                    onClick={this.onclickfunctioninput}
                    testid="searchButton"
                    className={`search-icon ${searchIcon}`}
                  >
                    <BsSearch />
                  </button>
                </div>
              </div>
            </div>
            <>
              <div className="nojob-container">
                <div className="middle-fail-container">
                  <img
                    src="https://res.cloudinary.com/dh5so11jh/image/upload/v1677318621/Asset_1_1nobooks_e1plcp.png"
                    alt="no books"
                    className="no-books-img"
                  />
                  <p className={`nojob-para ${errorPars}`}>
                    Your search for {searchValue} did not find any matches.
                  </p>
                </div>
              </div>
            </>
          </div>
        </div>
      </div>
    )
  }

  successFunction = () => {
    const {itemsList} = this.state
    const {selectedTab, searchValue, active} = this.state
    const varun = bookshelvesList.filter(
      eachitem => eachitem.value === selectedTab,
    )
    const gty = bookshelvesList.filter(eachitem => {
      console.log(eachitem.value)
      console.log(selectedTab)
      console.log(eachitem.value === selectedTab)
      return eachitem.value === selectedTab
    })
    const result = JSON.parse(localStorage.getItem('buttonTab'))
    const final = varun[0].label
    const head = active ? 'Bookshelves' : 'Book Shelves'
    const bgColorBottom = JSON.parse(localStorage.getItem('bgTheme'))
    const bottomColor = bgColorBottom
      ? 'dark-theme-book-shelves'
      : 'light-theme-book-shelves'
    const sideBarBg = bgColorBottom ? 'dark-side-theme' : 'light-side-theme'
    const sideMainHeading = bgColorBottom
      ? 'side-dark-color'
      : 'side-light-color'
    const inputBg = bgColorBottom ? 'dark-input-theme' : 'light-input-theme'
    const searchIcon = bgColorBottom
      ? 'dark-search-button'
      : 'light-search-button'
    return (
      <div className={`book-shelves-container ${bottomColor}`}>
        <div className="tabs-for-small-cont">
          <>{result ? <TabsForSmall /> : null}</>
        </div>
        <div className="search-small-container">
          <div className="input-search-cont">
            <input
              type="search"
              placeholder="Search"
              className={`input-ele ${inputBg}`}
              value={searchValue}
              onChange={this.searchValueChangeFunction}
            />
            <button
              type="button"
              onClick={this.onclickfunctioninput}
              testid="searchButton"
              className={`search-icon ${searchIcon}`}
            >
              <BsSearch />
            </button>
          </div>
        </div>
        <div className="item-bottom-container">
          <div className={`side-bar-container ${sideBarBg}`}>
            <h1 className={`books-heading ${sideMainHeading}`}>{head}</h1>
            <nav>
              <ul className="list-side-bar-container">
                {bookshelvesList.map(eachitem => (
                  <SideBarComponent
                    key={eachitem.id}
                    sub={eachitem}
                    tabChangeFunction={this.tabChangeFunction}
                    tiru={eachitem.value === selectedTab}
                  />
                ))}
              </ul>
            </nav>
          </div>

          <div className="first-container-item">
            <div className="search-book-cont">
              <div className="books-search-container">
                <h1 className={`type-of-books ${sideMainHeading}`}>
                  {final} Books
                </h1>

                <div className="input-search-cont">
                  <input
                    type="search"
                    placeholder="Search"
                    className={`input-ele ${inputBg}`}
                    value={searchValue}
                    onChange={this.searchValueChangeFunction}
                  />
                  <button
                    type="button"
                    onClick={this.onclickfunctioninput}
                    testid="searchButton"
                    className={`search-icon ${searchIcon}`}
                  >
                    <BsSearch />
                  </button>
                </div>
              </div>
            </div>
            <>
              <ul className="list-item-container-bottom">
                {itemsList.map(eachitem => (
                  <BooksList key={eachitem.id} sub={eachitem} />
                ))}
              </ul>
              <Footer />
            </>
          </div>
        </div>
      </div>
    )
  }

  render() {
    return (
      <div>
        <Header />
        <>{this.switchingFunction()}</>
      </div>
    )
  }
}
export default BookShelvesComponent
