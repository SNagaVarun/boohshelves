import ContextComponent from '../../ContextComponent/Context'
import CartList from '../CartList'
import Header from '../Header'
import './index.css'

const CartCompo = () => (
  <ContextComponent.Consumer>
    {value => {
      const {cartList} = value
      return (
        <>
          <Header />
          <div className="cart-bottom-container">
            {cartList.length > 0 ? (
              <ul className="cart-list-container">
                {cartList.map(eachitem => (
                  <CartList key={eachitem.id} sub={eachitem} />
                ))}
              </ul>
            ) : (
              <div>
                <h1>No Items in the Cart</h1>
              </div>
            )}
          </div>
        </>
      )
    }}
  </ContextComponent.Consumer>
)
export default CartCompo
