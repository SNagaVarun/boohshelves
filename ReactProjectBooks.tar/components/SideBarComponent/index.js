import './index.css'

const SideBarComponent = props => {
  const {key, sub, tabChangeFunction, tiru} = props
  const tirumala = () => {
    tabChangeFunction(sub.id)
  }
  const result = tiru ? 'display-items' : 'button-class'
  return (
    <li key={key} className="list-side-items">
      <button type="button" className={result} onClick={tirumala}>
        {sub.label}
      </button>
    </li>
  )
}
export default SideBarComponent
