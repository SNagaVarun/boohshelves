import {Link} from 'react-router-dom'
import {BsFillStarFill} from 'react-icons/bs'
import './index.css'

const BooksList = props => {
  const {key, sub} = props
  const result = JSON.parse(localStorage.getItem('bgTheme'))
  const titleColor = result ? 'dark-list-theme' : 'light-list-theme'
  const contentsTop = result ? 'content-top-dark' : 'content-top-light'
  return (
    <Link to={`/books/${sub.id}`} className="link-items" testid="bookItem">
      <li key={key} className="img-content-container" testid="bookItem">
        <img src={sub.coverPic} alt={sub.title} className="thumbnail-img" />
        <div className="list-of-container">
          <h1 className={`title ${titleColor}`}>{sub.title}</h1>
          <p className={`authors-name ${contentsTop}`}>{sub.authorName}</p>
          <p className={`rating-para ${contentsTop}`}>
            Avg Rating{' '}
            <span className="star">
              <BsFillStarFill />
            </span>{' '}
            {sub.rating}
          </p>
          <p className={`status-para ${contentsTop}`}>
            Status: <span className="span-content">{sub.readStatus}</span>
          </p>
        </div>
      </li>
    </Link>
  )
}
export default BooksList
