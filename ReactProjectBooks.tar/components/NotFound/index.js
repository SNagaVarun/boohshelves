import {Link} from 'react-router-dom'
import './index.css'

const NotFound = () => {
  const result = JSON.parse(localStorage.getItem('bgTheme'))
  const headingColor = result ? 'dark-error-heading' : 'light-error-heading'
  const paraColor = result ? 'dark-error-para' : 'light-error-para'
  const bgNot = result ? 'not-bg-dark' : 'not-bg-light'
  return (
    <>
      <div className="not-found-large">
        <div className={`not-found-container ${bgNot}`}>
          <div className="second-not-found-container">
            <img
              src="https://res.cloudinary.com/dh5so11jh/image/upload/v1677256070/Group_7484not-found_vlfbib.png"
              alt="not found"
              className="not-found-img"
            />
            <h1 className={`page-not-found-heading ${headingColor}`}>
              Page Not Found
            </h1>
            <p className={`request-para ${paraColor}`}>
              we are sorry, the page you requested could not be found, Please go
              back to the homepage.
            </p>
            <Link to="/">
              <button type="button" className="go-button">
                Go Back to Home
              </button>
            </Link>
          </div>
        </div>
      </div>
      <div className="first-not-found-container">
        <div className={`not-container-small-first ${bgNot}`}>
          <div className="not-small-second-container">
            <img
              src="https://res.cloudinary.com/dh5so11jh/image/upload/v1677256070/Group_7484not-found_vlfbib.png"
              alt="not found"
              className="not-found-img-small"
            />
            <h1 className={`page-not-found-heading ${headingColor}`}>
              Page Not Found
            </h1>
            <p className={`request-para ${paraColor}`}>
              we are sorry, the page you requested could not be found, Please go
              back to the homepage.
            </p>
            <Link to="/">
              <button type="button" className="go-button">
                Go Back to Home
              </button>
            </Link>
          </div>
        </div>
      </div>
    </>
  )
}

export default NotFound
