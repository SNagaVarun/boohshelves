import Popup from 'reactjs-popup'
import Cookies from 'js-cookie'
import {Component} from 'react'
import {AiFillCloseCircle} from 'react-icons/ai'
import {HiMoon, HiOutlineLightBulb} from 'react-icons/hi'
import HomeTabs from '../HomeTabs'
import ContextComponent from '../../ContextComponent/Context'
import './index.css'

const homeTabs = [
  {title: 'Home', id: 1, rte: '/'},
  {title: 'Bookshelves', rte: '/shelf', id: 2},
]

class TabsForSmall extends Component {
  state = {
    present: homeTabs[0].route,
    buttonStatus: JSON.parse(localStorage.getItem('buttonTab')),
  }

  onchangefunction = para => {
    const updated = homeTabs.filter(eachitem => eachitem.route === para)
    this.setState({present: updated[0].route})
  }

  humberFunction = () => {}

  storingFunction = () => {
    const {buttonStatus} = this.state
    console.log(buttonStatus)
    localStorage.setItem('buttonTab', JSON.stringify(buttonStatus))
  }

  logoutFunction = () => {
    Cookies.remove('jwt_token')
    localStorage.setItem('id', 1)
    localStorage.setItem('state', 'ALL')
    const {history} = this.props
    history.replace('/login')
    localStorage.setItem('buttonTab', 'false')
  }

  render() {
    const {present} = this.state
    const result = JSON.parse(localStorage.getItem('bgTheme'))
    const tirumala = result ? 'moon-icon-dark-img' : 'moon-icon-light-img'
    return (
      <>
        <ContextComponent.Consumer>
          {value => {
            const {buttonstatusChange, themeChangeFunction} = value
            const humberFunction = () => {
              buttonstatusChange()
            }
            const gototirumala = () => {
              themeChangeFunction()
            }
            return (
              <div>
                <ul className="home-for-small">
                  {homeTabs.map(eachitem => (
                    <HomeTabs
                      key={eachitem.id}
                      sub={eachitem}
                      onchangefunction={this.onchangefunction}
                      varun={eachitem.route === present}
                    />
                  ))}
                  {result ? (
                    <li>
                      <button
                        type="button"
                        onClick={gototirumala}
                        className={tirumala}
                      >
                        <HiOutlineLightBulb />
                      </button>
                    </li>
                  ) : (
                    <li>
                      <button
                        type="button"
                        onClick={gototirumala}
                        className={tirumala}
                      >
                        <HiMoon />
                      </button>
                    </li>
                  )}

                  <li>
                    <Popup
                      modal
                      trigger={
                        <button type="button" className="logout-button">
                          Logout
                        </button>
                      }
                    >
                      {close => (
                        <div className="pop-up-container">
                          <div>
                            <p>Are you sure you want to logout?</p>
                          </div>
                          <div>
                            <button
                              type="button"
                              className="cancel-button"
                              onClick={() => close()}
                            >
                              Cancel
                            </button>
                            <button
                              type="button"
                              className="logout-button"
                              onClick={this.logoutFunction}
                            >
                              Confirm
                            </button>
                          </div>
                        </div>
                      )}
                    </Popup>
                  </li>
                  <li>
                    <button
                      type="button"
                      className="close-button"
                      onClick={humberFunction}
                    >
                      <AiFillCloseCircle className="ai-close-icon" />
                    </button>
                  </li>
                </ul>
              </div>
            )
          }}
        </ContextComponent.Consumer>
      </>
    )
  }
}
export default TabsForSmall
