import {Component} from 'react'
import {Redirect} from 'react-router-dom'
import Cookies from 'js-cookie'
import './index.css'

class LoginForm extends Component {
  state = {
    username: '',
    password: '',
    errorMsg: '',
    checkboxStatus: false,
  }

  usernameChangeFunction = event => {
    this.setState({username: event.target.value})
  }

  passwordChangeFunction = event => {
    this.setState({password: event.target.value})
  }

  submittingFunction = event => {
    event.preventDefault()
    this.getDetails()
  }

  getDetails = async () => {
    const {username, password} = this.state
    const url = 'https://apis.ccbp.in/login'
    const userDetails = {
      username,
      password,
    }
    const option = {
      method: 'POST',
      body: JSON.stringify(userDetails),
    }
    const response = await fetch(url, option)
    console.log(response)
    if (response.ok === true) {
      const data = await response.json()
      Cookies.set('jwt_token', data.jwt_token, {expires: 30})
      const {history} = this.props
      history.replace('/')
    } else {
      const data = await response.json()
      this.setState({errorMsg: data.error_msg})
    }
  }

  checkboxFunction = () => {
    this.setState(prevstate => ({checkboxStatus: !prevstate.checkboxStatus}))
  }

  render() {
    const {username, password, errorMsg, checkboxStatus} = this.state
    const token = Cookies.get('jwt_token')
    if (token !== undefined) {
      return <Redirect to="/" />
    }
    const passwordShow = checkboxStatus ? 'text' : 'password'
    return (
      <>
        <div className="large-container">
          <div className="base-container">
            <img
              src="https://res.cloudinary.com/dh5so11jh/image/upload/v1676995165/Rectangle_1467varun_xonaxy.png"
              alt="website login"
              className="firstContainer"
            />
            <div className="second-container">
              <div className="form-container">
                <div className="logo-container">
                  <img
                    src="https://res.cloudinary.com/dh5so11jh/image/upload/v1677059023/Group_7731logo_rid3l5.png"
                    className="logo-img"
                    alt="login website logo"
                  />
                </div>
                <form onSubmit={this.submittingFunction}>
                  <label htmlFor="username" className="username-text">
                    Username*
                  </label>
                  <br />
                  <input
                    type="text"
                    placeholder="Username"
                    id="username"
                    className="userinput-ele"
                    value={username}
                    onChange={this.usernameChangeFunction}
                  />
                  <br />
                  <label htmlFor="password" className="password-text">
                    Password*
                  </label>
                  <br />
                  <input
                    type={passwordShow}
                    placeholder="Password"
                    id="password"
                    className="password-ele"
                    value={password}
                    onChange={this.passwordChangeFunction}
                  />
                  <div className="checkbox-container">
                    <input
                      type="checkbox"
                      id="checkbox"
                      onClick={this.checkboxFunction}
                    />
                    <label htmlFor="checkbox" className="show-password">
                      Show Password
                    </label>
                  </div>
                  {errorMsg.length > 0 ? (
                    <p className="error-msg">{errorMsg}</p>
                  ) : null}
                  <div>
                    <button type="submit" className="login-button">
                      Login
                    </button>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
        <div className="small-container">
          <div className="login-small-container">
            <div className="image-container">
              <img
                src="https://res.cloudinary.com/dh5so11jh/image/upload/v1676995165/Rectangle_1467varun_xonaxy.png"
                alt="website login"
                className="firstContainer"
              />
            </div>
            <div className="second-container">
              <div className="form-container">
                <div className="logo-container">
                  <img
                    src="https://res.cloudinary.com/dh5so11jh/image/upload/v1677059023/Group_7731logo_rid3l5.png"
                    className="logo-img"
                    alt="login website logo"
                  />
                </div>
                <form onSubmit={this.submittingFunction}>
                  <label htmlFor="username" className="username-text">
                    Username*
                  </label>
                  <br />
                  <input
                    type="text"
                    placeholder="Username"
                    id="username"
                    className="userinput-ele"
                    value={username}
                    onChange={this.usernameChangeFunction}
                  />
                  <br />
                  <label htmlFor="password" className="password-text">
                    Password*
                  </label>
                  <br />
                  <input
                    type={passwordShow}
                    placeholder="Password"
                    id="password"
                    className="password-ele"
                    value={password}
                    onChange={this.passwordChangeFunction}
                  />
                  <div className="checkbox-container">
                    <input
                      type="checkbox"
                      id="checkbox"
                      onClick={this.checkboxFunction}
                    />
                    <label htmlFor="checkbox" className="show-password">
                      Show Password
                    </label>
                  </div>
                  {errorMsg.length > 0 ? (
                    <p className="error-msg">{errorMsg}</p>
                  ) : null}
                  <div>
                    <button type="submit" className="login-button">
                      Login
                    </button>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </>
    )
  }
}
export default LoginForm
