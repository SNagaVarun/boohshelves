import {Link} from 'react-router-dom'
import ContextComponent from '../../ContextComponent/Context'
import './index.css'

const HomeTabs = props => {
  const {key, sub} = props
  const {rte, id} = sub
  return (
    <ContextComponent.Consumer>
      {value => {
        const {presentChange} = value
        const tiru = JSON.parse(localStorage.getItem('id'))
        const varun = id === tiru
        const tirumala = varun ? 'home-text' : 'not-selected'
        const tirumalafunction = () => {
          presentChange(sub.title)
        }
        return (
          <>
            <li key={key} onClick={tirumalafunction}>
              <Link to={rte} className={`link-class ${tirumala}`}>
                {sub.title}
              </Link>
            </li>
          </>
        )
      }}
    </ContextComponent.Consumer>
  )
}
export default HomeTabs
