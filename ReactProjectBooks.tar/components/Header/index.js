import {withRouter, Link} from 'react-router-dom'
import {Component} from 'react'
import Cookies from 'js-cookie'
import Popup from 'reactjs-popup'
import {HiMoon, HiOutlineLightBulb} from 'react-icons/hi'
import HomeTabs from '../HomeTabs'
import ContextComponent from '../../ContextComponent/Context'
import './index.css'

const homeTabs = [
  {title: 'Home', id: 1, rte: '/'},
  {title: 'Bookshelves', rte: '/shelf', id: 2},
  {title: 'Cart', rte: '/cart', id: 3},
]

class Header extends Component {
  state = {
    present: homeTabs[0].route,
    buttonStatus: JSON.parse(localStorage.getItem('buttonTab')),
    theme: JSON.parse(localStorage.getItem('bgTheme')),
  }

  onchangefunction = para => {
    const updated = homeTabs.filter(eachitem => eachitem.route === para)
    this.setState({present: updated[0].route})
  }

  details = () => {
    const {buttonStatus} = this.state
    console.log(buttonStatus)
    localStorage.setItem('buttonTab', JSON.stringify(buttonStatus))
  }

  logoutFunction = () => {
    Cookies.remove('jwt_token')
    localStorage.setItem('id', 1)
    localStorage.setItem('state', 'ALL')
    localStorage.setItem('buttonTab', 'false')
    localStorage.setItem('bgTheme', 'false')
    const {history} = this.props
    history.replace('/login')
  }

  render() {
    const {present} = this.state
    const result = JSON.parse(localStorage.getItem('bgTheme'))
    const bgColor = result ? 'nav-container-dark' : 'nav-container-light'
    const lightmodebtn = result ? 'moon-img-in-dark' : 'moon-img'
    const smallNav = result
      ? 'small-nav-dark-container'
      : 'small-nav-light-container'
    return (
      <ContextComponent.Consumer>
        {value => {
          const {buttonstatusChange, themeChangeFunction} = value
          const humbergerFunction = () => {
            buttonstatusChange()
          }
          const themeFunction = () => {
            themeChangeFunction()
          }
          return (
            <>
              <div className="nav-for-large">
                <nav className={bgColor}>
                  <ul className="first-list-container">
                    <li>
                      <Link to="/">
                        <img
                          src="https://res.cloudinary.com/dh5so11jh/image/upload/v1677059023/Group_7731logo_rid3l5.png"
                          alt="website logo"
                          className="logo-img"
                        />
                      </Link>
                    </li>
                    <li>
                      <ul className="second-list-container">
                        {homeTabs.map(eachitem => (
                          <HomeTabs
                            key={eachitem.title}
                            sub={eachitem}
                            onchangefunction={this.onchangefunction}
                            varun={eachitem.route === present}
                          />
                        ))}
                        {result ? (
                          <li className="moon-container">
                            <button
                              type="button"
                              onClick={themeFunction}
                              className={lightmodebtn}
                            >
                              <HiOutlineLightBulb />
                            </button>
                          </li>
                        ) : (
                          <li className="moon-container">
                            <button
                              type="button"
                              className={lightmodebtn}
                              onClick={themeFunction}
                            >
                              <HiMoon />
                            </button>
                          </li>
                        )}

                        <li>
                          <Popup
                            modal
                            trigger={
                              <button type="button" className="logout-button">
                                Logout
                              </button>
                            }
                          >
                            {close => (
                              <div className="pop-up-container">
                                <div>
                                  <p>Are you sure you want to logout?</p>
                                </div>
                                <div>
                                  <button
                                    type="button"
                                    className="cancel-button"
                                    onClick={() => close()}
                                  >
                                    Cancel
                                  </button>
                                  <button
                                    type="button"
                                    className="confirm-button"
                                    onClick={this.logoutFunction}
                                  >
                                    Confirm
                                  </button>
                                </div>
                              </div>
                            )}
                          </Popup>
                        </li>
                      </ul>
                    </li>
                  </ul>
                </nav>
              </div>
              <div className="small-container-nav">
                <nav className={smallNav}>
                  <ul className="small-list-container">
                    <li>
                      <Link to="/">
                        <img
                          src="https://res.cloudinary.com/dh5so11jh/image/upload/v1677059023/Group_7731logo_rid3l5.png"
                          alt="website logo"
                          className="logo-img"
                        />
                      </Link>
                    </li>
                    <li>
                      <button
                        type="button"
                        className="humberg-button"
                        onClick={humbergerFunction}
                      >
                        <img
                          src="https://res.cloudinary.com/dh5so11jh/image/upload/v1678732303/iconicon_aa9o6i.png"
                          alt="humberger"
                        />
                      </button>
                    </li>
                  </ul>
                </nav>
              </div>
            </>
          )
        }}
      </ContextComponent.Consumer>
    )
  }
}
export default withRouter(Header)
