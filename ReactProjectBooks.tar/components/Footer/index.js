import './index.css'
import {FaGoogle, FaTwitter, FaInstagram, FaYoutube} from 'react-icons/fa'

const Footer = () => {
  const theme = JSON.parse(localStorage.getItem('bgTheme'))
  const iconColor = theme ? 'dark-icon' : 'light-icon'
  return (
    <>
      <div className="footer-container">
        <FaGoogle className={`icon-class ${iconColor}`} />
        <FaTwitter className={`icon-class ${iconColor}`} />
        <FaInstagram className={`icon-class ${iconColor}`} />
        <FaYoutube className={`icon-class ${iconColor}`} />
      </div>
      <p className={`contact-heading ${iconColor}`}>Contact Us</p>
    </>
  )
}
export default Footer
