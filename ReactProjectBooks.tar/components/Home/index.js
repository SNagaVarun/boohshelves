import {Component} from 'react'
import Slider from 'react-slick'
import {Link} from 'react-router-dom'
import 'slick-carousel/slick/slick.css'
import 'slick-carousel/slick/slick-theme.css'
import Loader from 'react-loader-spinner'
import Cookies from 'js-cookie'
import Header from '../Header'
import SlideComponent from '../SlideComponent'
import Footer from '../Footer'
import TabsForSmall from '../TabsForSmall'
import './index.css'

const apistatus = {
  initial: 'INITIAL',
  inProgress: 'Loader',
  failure: 'Failure',
  success: 'SUCCESS',
}

class Home extends Component {
  state = {
    itemsList: [],
    status: apistatus.initial,
  }

  componentDidMount() {
    this.setState({status: apistatus.inProgress})
    localStorage.setItem('state', JSON.stringify('ALL'))
    this.getDetails()
  }

  getDetails = async () => {
    const url = 'https://apis.ccbp.in/book-hub/top-rated-books'
    const token = Cookies.get('jwt_token')
    localStorage.setItem('id', JSON.stringify(1))
    const option = {
      method: 'GET',
      headers: {
        Authorization: `Bearer ${token}`,
      },
    }
    const response = await fetch(url, option)
    if (response.ok === true) {
      const data = await response.json()
      const {books} = data
      const updatedList = books.map(eachitem => {
        const sub = {
          authorName: eachitem.author_name,
          id: eachitem.id,
          coverPic: eachitem.cover_pic,
          title: eachitem.title,
        }
        return sub
      })
      this.setState({itemsList: updatedList, status: apistatus.success})
    } else {
      this.setState({status: apistatus.failure})
    }
  }

  tryAgainFunction = () => {
    this.setState({status: apistatus.inProgress}, this.getDetails)
  }

  swithchingFunction = () => {
    const {status} = this.state
    switch (true) {
      case status === apistatus.inProgress:
        return this.loadingFunction()
      case status === apistatus.success:
        return this.successFunction()
      case status === apistatus.failure:
        return this.failureFunction()
      default:
        return null
    }
  }

  loadingFunction = () => {
    const theme = JSON.parse(localStorage.getItem('bgTheme'))
    const bgColor = theme ? 'dark-theme' : 'light-theme'
    return (
      <div className={`loader-first-container ${bgColor}`}>
        <div className="loader-container" testid="loader">
          <Loader type="TailSpin" color="#0284C7" height={50} width={50} />
        </div>
      </div>
    )
  }

  failureFunction = () => {
    const result = JSON.parse(localStorage.getItem('buttonTab'))
    const theme = JSON.parse(localStorage.getItem('bgTheme'))
    const bgColor = theme ? 'dark-theme' : 'light-theme'
    const headingColor = theme ? 'dark-theme-heading' : 'light-theme-heading'
    const firstPara = theme ? 'dark-theme-para' : 'light-theme-para'
    const slideBGColor = theme ? 'dark-theme-slide' : 'light-theme-slide'
    const topRated = theme ? 'dark-top-rated' : 'light-top-rated'
    return (
      <div className={`bottom-container ${bgColor}`}>
        <div className="tabs-container">
          <>{result ? <TabsForSmall /> : null}</>
        </div>
        <h1 className={`heading ${headingColor}`}>
          Find Your Next Favorite Books?
        </h1>
        <p className={`para-content ${firstPara}`}>
          You are in the right place. Tell us what titles or genres you have
          enjoyed in the past, and we will give you surprisingly insightful
          recommendations.
        </p>
        <div className="find-button-show">
          <Link to="/shelf">
            <button type="button" className="find-books-button">
              Find Books
            </button>
          </Link>
        </div>
        <div className={`slide-container ${slideBGColor}`}>
          <div className="slide-show">
            <ul className="find-top-container" key="top-rated">
              <li key="top-rated">
                <h1 className={`top-rated-para ${topRated}`}>
                  Top Rated Books
                </h1>
              </li>
              <Link to="/shelf">
                <li key="button-find">
                  <button type="button" className="find-books-button">
                    Find Books
                  </button>
                </li>
              </Link>
            </ul>
          </div>
          <div className="top-heading-show">
            <h1 className={`top-rated-para-mini ${topRated}`}>
              Top Rated Books
            </h1>
          </div>
          <div className="failure-first-container">
            <img
              src="https://res.cloudinary.com/dh5so11jh/image/upload/v1677258750/Group_7522details-wrong_t7zbet.png"
              alt="failure view"
              className="failure-img"
            />
            <p className="something-para">
              Something went wrong, Please try again.
            </p>
            <button
              type="button"
              className="try-again-button"
              onClick={this.tryAgainFunction}
            >
              Try Again
            </button>
          </div>
        </div>
      </div>
    )
  }

  successFunction = () => {
    const {itemsList} = this.state
    const settings = {
      dots: false,
      slidesToShow: 4,
      slidesToScroll: 1,
    }
    const parameter = {
      dots: false,
      slidesToShow: 2,
      slidesToScroll: 1,
    }
    const result = JSON.parse(localStorage.getItem('buttonTab'))
    const theme = JSON.parse(localStorage.getItem('bgTheme'))
    const bgColor = theme ? 'dark-theme' : 'light-theme'
    const headingColor = theme ? 'dark-theme-heading' : 'light-theme-heading'
    const firstPara = theme ? 'dark-theme-para' : 'light-theme-para'
    const slideBGColor = theme ? 'dark-theme-slide' : 'light-theme-slide'
    const topRated = theme ? 'dark-top-rated' : 'light-top-rated'
    return (
      <div className={`bottom-container ${bgColor}`}>
        <div className="tabs-container">
          <>{result ? <TabsForSmall /> : null}</>
        </div>
        <h1 className={`heading ${headingColor}`}>
          Find Your Next Favorite Books?
        </h1>
        <p className={`para-content ${firstPara}`}>
          You are in the right place. Tell us what titles or genres you have
          enjoyed in the past, and we will give you surprisingly insightful
          recommendations.
        </p>
        <div className="find-button-show">
          <Link to="/shelf">
            <button type="button" className="find-books-button">
              Find Books
            </button>
          </Link>
        </div>
        <div className={`slide-container ${slideBGColor}`}>
          <div className="slide-show">
            <ul className="find-top-container" key="top-rated">
              <li key="top-rated">
                <h1 className={`top-rated-para ${topRated}`}>
                  Top Rated Books
                </h1>
              </li>
              <Link to="/shelf">
                <li key="button-find">
                  <button type="button" className="find-books-button">
                    Find Books
                  </button>
                </li>
              </Link>
            </ul>
          </div>
          <div className="top-heading-show">
            <h1 className={`top-rated-para-mini ${topRated}`}>
              Top Rated Books
            </h1>
          </div>
          <div className="success-for-large">
            <ul className="list-container">
              <Slider {...settings}>
                {itemsList.map(eachitem => (
                  <SlideComponent key={eachitem.id} sub={eachitem} />
                ))}
              </Slider>
            </ul>
          </div>
          <div className="success-for-small">
            <ul className="list-container">
              <Slider {...parameter}>
                {itemsList.map(eachitem => (
                  <SlideComponent key={eachitem.id} sub={eachitem} />
                ))}
              </Slider>
            </ul>
          </div>
        </div>
        <Footer />
      </div>
    )
  }

  render() {
    return (
      <>
        <Header />
        <>{this.swithchingFunction()}</>
      </>
    )
  }
}
export default Home
