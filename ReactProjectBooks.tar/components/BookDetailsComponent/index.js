import {Component} from 'react'
import Cookies from 'js-cookie'
import Loader from 'react-loader-spinner'
import {BsFillStarFill} from 'react-icons/bs'
import Header from '../Header'
import Footer from '../Footer'
import TabsForSmall from '../TabsForSmall'
import ContextComponent from '../../ContextComponent/Context'
import './index.css'

const apistatus = {
  initial: 'INITIAL',
  inProgress: 'Loader',
  failure: 'Failure',
  success: 'SUCCESS',
}

class BookDetailsComponent extends Component {
  state = {
    bookDetails: {},
    status: apistatus.initial,
    buttonStatus: JSON.parse(localStorage.getItem('buttonTab')),
  }

  componentDidMount() {
    this.setState({status: apistatus.inProgress})
    this.getDetails()
  }

  getDetails = async () => {
    const {match} = this.props
    const {params} = match
    const {id} = params
    const token = Cookies.get('jwt_token')
    localStorage.setItem('id', 5)
    const url = `https://apis.ccbp.in/book-hub/books/${id}`
    const option = {
      method: 'GET',
      headers: {
        Authorization: `Bearer ${token}`,
      },
    }
    const response = await fetch(url, option)
    if (response.ok === true) {
      const data = await response.json()
      const details = data.book_details
      const updatedData = {
        aboutAuthor: details.about_author,
        aboutBook: details.about_book,
        authorName: details.author_name,
        coverPic: details.cover_pic,
        id: details.id,
        rating: details.rating,
        readStatus: details.read_status,
        title: details.title,
      }
      this.setState({status: apistatus.success, bookDetails: updatedData})
    } else {
      this.setState({status: apistatus.failure})
    }
  }

  retryFunction = () => {
    this.setState({status: apistatus.inProgress}, this.getDetails)
  }

  swithchingFunction = () => {
    const {status} = this.state
    switch (true) {
      case status === apistatus.inProgress:
        return this.loadingFunction()
      case status === apistatus.success:
        return this.successFunction()
      case status === apistatus.failure:
        return this.failureFunction()
      default:
        return null
    }
  }

  loadingFunction = () => {
    const bgCover = JSON.parse(localStorage.getItem('bgTheme'))
    const bgResult = bgCover ? 'dark-details-theme' : 'light-details-theme'
    return (
      <div className={`loader-first-container ${bgResult}`}>
        <div className="loader-container" testid="loader">
          <Loader type="TailSpin" color="#0284C7" height={50} width={50} />
        </div>
      </div>
    )
  }

  failureFunction = () => {
    const bgCover = JSON.parse(localStorage.getItem('bgTheme'))
    const bgResult = bgCover ? 'dark-details-theme' : 'light-details-theme'
    const contentsTop = bgCover ? 'content-top-dark' : 'content-top-light'
    return (
      <div className={`failure-view-book-container ${bgResult}`}>
        <div className="failure-first-container">
          <img
            src="https://res.cloudinary.com/dh5so11jh/image/upload/v1677258750/Group_7522details-wrong_t7zbet.png"
            alt="failure view"
            className="failure-image"
          />
          <p className={`error-heading ${contentsTop}`}>
            Something went wrong, Please try again.
          </p>
          <button
            type="button"
            className="button-try-again"
            onClick={this.retryFunction}
          >
            Try Again
          </button>
        </div>
      </div>
    )
  }

  successFunction = () => {
    const {bookDetails} = this.state
    const {
      aboutAuthor,
      aboutBook,
      authorName,
      coverPic,
      rating,
      readStatus,
      title,
      id,
    } = bookDetails
    const {buttonStatus} = this.props
    console.log(buttonStatus)
    const result2 = JSON.parse(localStorage.getItem('buttonTab'))
    const bgCover = JSON.parse(localStorage.getItem('bgTheme'))
    const bgResult = bgCover ? 'dark-details-theme' : 'light-details-theme'
    const bgSecond = bgCover
      ? 'dark-second-container'
      : 'light-second-container'
    const heading = bgCover ? 'content-heading-dark' : 'content-heading-light'
    const contentsTop = bgCover ? 'content-top-dark' : 'content-top-light'
    console.log(result2)
    return (
      <div className={`bottom-books-container ${bgResult}`}>
        <div className="tabs-small-details">
          <>{result2 ? <TabsForSmall /> : null}</>
        </div>
        <div className={`content-container ${bgSecond}`}>
          <div className="image-content-container">
            <img src={coverPic} alt={title} className="cover-pic" />
            <div className="content-side-container">
              <h1 className={`image-heading ${heading}`}>{title}</h1>
              <p className={`author-name ${contentsTop}`}>{authorName}</p>
              <p className={`avg-rating-para ${contentsTop}`}>
                Avg Rating <BsFillStarFill className="star-img" /> {rating}
              </p>
              <p className={`status-content ${contentsTop}`}>
                Status: <span className="span-element">{readStatus}</span>
              </p>
              <ContextComponent.Consumer>
                {value => {
                  const {cartListChange} = value
                  const addingToCart = () => {
                    cartListChange(bookDetails)
                  }
                  return (
                    <button
                      type="button"
                      onClick={addingToCart}
                      className="adding-button"
                    >
                      Add to cart
                    </button>
                  )
                }}
              </ContextComponent.Consumer>
            </div>
          </div>
          <hr className="horizontal-line" />
          <div>
            <h1 className={`about-author-heading ${heading}`}>About Author</h1>
            <p className={`about-author-content ${contentsTop}`}>
              {aboutAuthor}
            </p>
            <h1 className={`about-author-heading ${heading}`}>About Book</h1>
            <p className={`about-author-content ${contentsTop}`}>{aboutBook}</p>
          </div>
        </div>
        <Footer />
      </div>
    )
  }

  render() {
    return (
      <div>
        <Header />
        <>{this.swithchingFunction()}</>
      </div>
    )
  }
}

export default BookDetailsComponent
