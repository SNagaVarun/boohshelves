import {Link} from 'react-router-dom'
import './index.css'

const SlideComponent = props => {
  const {key, sub} = props
  const result = JSON.parse(localStorage.getItem('bgTheme'))
  const headingColor = result
    ? 'dark-theme-heading-slide'
    : 'light-theme-heading-slide'
  const paraColor = result ? 'dark-theme-para-slide' : 'light-theme-para-slide'
  return (
    <Link to={`/books/${sub.id}`} className="link-container" testid="bookItem">
      <li key={key} className="slide-list-container" testid="bookItem">
        <img src={sub.coverPic} alt={sub.title} className="slide-img" />
        <h1 className={`title-content ${headingColor}`}>{sub.title}</h1>
        <p className={`author-para ${paraColor}`}>{sub.authorName}</p>
      </li>
    </Link>
  )
}
export default SlideComponent
