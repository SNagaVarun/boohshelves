import React from 'react'

let varun = null
let active = null
let buttonstatus = null
let theme = null
let cartItemList = []
const tirumala = JSON.parse(localStorage.getItem('id'))
if (tirumala === null) {
  localStorage.setItem('id', 1)
  varun = localStorage.getItem('id')
} else {
  varun = localStorage.getItem('id')
}

const cartList = localStorage.getItem('CartList')
if (cartList === null) {
  localStorage.setItem('CartList', JSON.stringify([]))
  cartItemList = JSON.parse(localStorage.getItem('CartList'))
} else {
  cartItemList = localStorage.getItem('CartList')
}

const presentTheme = JSON.parse(localStorage.getItem('bgTheme'))
if (presentTheme === null) {
  localStorage.setItem('bgTheme', 'false')
  theme = localStorage.getItem('bgTheme')
} else {
  theme = localStorage.getItem('bgTheme')
}

const tab = localStorage.getItem('state')
if (tab === null) {
  localStorage.setItem('state', 'ALL')
  active = localStorage.getItem('state')
} else {
  active = localStorage.getItem('state')
}
const buttonActive = JSON.parse(localStorage.getItem('buttonTab'))
if (buttonActive === null) {
  localStorage.setItem('buttonTab', false)
  buttonstatus = localStorage.getItem('buttonTab')
} else {
  buttonstatus = localStorage.getItem('buttonTab')
}
const ContextComponent = React.createContext({
  present: varun,
  presentChange: () => {},
  activeTab: active,
  activeTabChange: () => {},
  buttonStatus: buttonstatus,
  buttonstatusChange: () => {},
  themeChangeFunction: () => {},
  cartList: cartItemList,
  cartListChange: () => {},
  removingCartItem: () => {},
})
export default ContextComponent
